import MabeleHeader from "@/components/mabele/MabeleHeader";
import HeroSection from "@/components/mabele/HeroSection";
import ServicesSection from "@/components/mabele/ServicesSection";
import TrustSection from "@/components/mabele/TrustSection";
import ComponentShowcase from "@/components/mabele/ComponentShowcase";
import KangaPaySection from "@/components/mabele/KangaPaySection";
import ScreensSection from "@/components/mabele/ScreensSection";
import BenefitsSection from "@/components/mabele/BenefitsSection";
import DownloadCTA from "@/components/mabele/DownloadCTA";
import MabeleFooter from "@/components/mabele/MabeleFooter";

const Index = () => (
  <div className="min-h-screen">
    <MabeleHeader />
    <HeroSection />
    <ServicesSection />
    <TrustSection />
    <ComponentShowcase />
    <KangaPaySection />
    <ScreensSection />
    <BenefitsSection />
    <DownloadCTA />
    <MabeleFooter />
  </div>
);

export default Index;
