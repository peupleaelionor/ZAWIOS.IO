import { motion } from "framer-motion";
import { Check, X, QrCode, Bell, Search, Star, Loader2, Home, Wallet } from "lucide-react";

const ComponentShowcase = () => (
  <section className="py-20 lg:py-32 relative overflow-hidden">
    <div className="absolute inset-0 pointer-events-none opacity-40">
      <div className="absolute top-20 right-20 w-96 h-96 rounded-full bg-golden/5 blur-3xl" />
    </div>

    <div className="container relative mx-auto px-4 lg:px-8">
      <motion.div
        className="text-center mb-14 lg:mb-20 max-w-3xl mx-auto"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <span className="inline-block px-3.5 py-1.5 rounded-full text-[11px] font-bold tracking-wider uppercase bg-golden/15 text-golden-deep mb-5">
          Design System
        </span>
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold mb-5 leading-[1.05]">
          Un <span className="text-gradient-brand">Design System</span> premium
        </h2>
        <p className="text-muted-foreground text-base lg:text-lg">
          Chaque composant est pensé pour une expérience fluide, intuitive et professionnelle. La cohérence visuelle au service de l'utilisateur.
        </p>
      </motion.div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {/* Buttons */}
        <Card title="Boutons">
          <div className="space-y-2.5">
            <button className="w-full py-3 gradient-golden text-accent-foreground font-bold rounded-xl text-sm shadow-golden">Primaire Doré</button>
            <button className="w-full py-3 gradient-royal text-primary-foreground font-bold rounded-xl text-sm shadow-royal">Secondaire Bleu</button>
            <button className="w-full py-3 border-2 border-royal/20 text-royal font-bold rounded-xl text-sm bg-background hover:border-royal/40 transition-colors">Outline</button>
          </div>
        </Card>

        {/* Badges */}
        <Card title="Badges & Status">
          <div className="flex flex-wrap gap-2">
            <span className="px-3 py-1.5 rounded-full text-xs font-bold bg-royal/10 text-royal ring-1 ring-royal/20">Vérifié</span>
            <span className="px-3 py-1.5 rounded-full text-xs font-bold bg-golden/15 text-golden-deep ring-1 ring-golden/30">Premium</span>
            <span className="px-3 py-1.5 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-700 ring-1 ring-emerald-500/20">Succès</span>
            <span className="px-3 py-1.5 rounded-full text-xs font-bold bg-brand-red/10 text-brand-red ring-1 ring-brand-red/20">Erreur</span>
            <span className="px-3 py-1.5 rounded-full text-xs font-bold bg-muted text-muted-foreground ring-1 ring-border">En attente</span>
          </div>
        </Card>

        {/* Search */}
        <Card title="Recherche">
          <div className="space-y-2">
            <div className="flex items-center gap-2 px-3.5 py-3 bg-background border-2 border-border rounded-xl focus-within:border-royal transition-colors">
              <Search size={16} className="text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Rechercher sur MABELE…</span>
            </div>
            <div className="flex flex-wrap gap-1.5">
              <span className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-royal/10 text-royal">Kinshasa</span>
              <span className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-muted text-muted-foreground">Maison</span>
              <span className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-muted text-muted-foreground">$500</span>
            </div>
          </div>
        </Card>

        {/* QR Card */}
        <Card title="QR KangaPay">
          <div className="flex flex-col items-center gap-3 py-1">
            <div className="relative">
              <div className="absolute inset-0 gradient-golden rounded-2xl blur-md opacity-40" />
              <div className="relative w-24 h-24 rounded-2xl gradient-royal flex items-center justify-center shadow-royal">
                <QrCode size={48} className="text-primary-foreground" />
              </div>
            </div>
            <span className="text-xs font-bold text-foreground">Scanner pour payer</span>
            <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">KangaPay · MABELE</span>
          </div>
        </Card>

        {/* Listing card */}
        <Card title="Carte Annonce">
          <div className="rounded-xl bg-surface-blue overflow-hidden ring-1 ring-border">
            <div className="relative h-20 gradient-midnight">
              <span className="absolute top-2 right-2 px-2 py-0.5 rounded-full text-[9px] font-bold bg-golden text-accent-foreground">VÉRIFIÉ</span>
            </div>
            <div className="p-3">
              <p className="font-extrabold text-sm">Appartement 3 pièces</p>
              <p className="text-xs text-muted-foreground">📍 Gombe, Kinshasa</p>
              <p className="text-base font-extrabold text-royal mt-1">$450<span className="text-xs font-medium text-muted-foreground">/mois</span></p>
            </div>
          </div>
        </Card>

        {/* Notification */}
        <Card title="Notifications">
          <div className="space-y-2">
            <div className="flex items-start gap-2.5 p-3 rounded-xl bg-royal/5 ring-1 ring-royal/10">
              <div className="w-7 h-7 rounded-lg bg-royal/15 flex items-center justify-center shrink-0">
                <Bell size={13} className="text-royal" />
              </div>
              <div><p className="text-xs font-bold">Nouveau message</p><p className="text-[10px] text-muted-foreground">De Marie K. il y a 5 min</p></div>
            </div>
            <div className="flex items-start gap-2.5 p-3 rounded-xl bg-golden/8 ring-1 ring-golden/15">
              <div className="w-7 h-7 rounded-lg bg-golden/20 flex items-center justify-center shrink-0">
                <Star size={13} className="text-golden-deep" />
              </div>
              <div><p className="text-xs font-bold">Avis 5 étoiles ⭐</p><p className="text-[10px] text-muted-foreground">Client satisfait</p></div>
            </div>
          </div>
        </Card>

        {/* States */}
        <Card title="États">
          <div className="space-y-2">
            <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-500/10 ring-1 ring-emerald-500/20">
              <Check size={16} className="text-emerald-600" />
              <span className="text-sm font-bold text-emerald-700">Paiement réussi</span>
            </div>
            <div className="flex items-center gap-2 p-3 rounded-xl bg-brand-red/10 ring-1 ring-brand-red/20">
              <X size={16} className="text-brand-red" />
              <span className="text-sm font-bold text-brand-red">Échec transaction</span>
            </div>
            <div className="flex items-center gap-2 p-3 rounded-xl bg-muted ring-1 ring-border">
              <Loader2 size={16} className="text-muted-foreground animate-spin" />
              <span className="text-sm font-bold text-muted-foreground">Chargement…</span>
            </div>
          </div>
        </Card>

        {/* Navigation */}
        <Card title="Navigation">
          <div className="flex items-center justify-around py-2 px-1 bg-background rounded-2xl border border-border shadow-sm">
            <NavItem icon={Home} label="Accueil" active />
            <NavItem icon={Search} label="Explorer" />
            <NavItem icon={Wallet} label="KangaPay" />
            <NavItem icon={Bell} label="Alertes" />
          </div>
        </Card>
      </div>
    </div>
  </section>
);

const Card = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <motion.div
    className="card-premium p-5"
    initial={{ opacity: 0, y: 15 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
  >
    <p className="text-[10px] font-extrabold text-muted-foreground uppercase tracking-[0.15em] mb-4">{title}</p>
    {children}
  </motion.div>
);

const NavItem = ({ icon: Icon, label, active }: { icon: any; label: string; active?: boolean }) => (
  <div className={`flex flex-col items-center gap-1 px-2 py-1 rounded-xl transition-colors ${active ? "text-royal bg-royal/10" : "text-muted-foreground"}`}>
    <Icon size={18} strokeWidth={active ? 2.4 : 2} />
    <span className="text-[10px] font-bold">{label}</span>
  </div>
);

export default ComponentShowcase;
