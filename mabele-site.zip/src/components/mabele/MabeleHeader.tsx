import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";
import mabeleLogo from "@/assets/mabele-logo.png";

const navLinks = [
  { label: "Immobilier", href: "#services" },
  { label: "Emploi", href: "#services" },
  { label: "Marché", href: "#services" },
  { label: "KangaPay", href: "#kangapay" },
  { label: "Agri", href: "#services" },
  { label: "SIKIN", href: "#services" },
];

const MabeleHeader = () => {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-background/85 backdrop-blur-xl border-b border-border/60 shadow-[0_1px_0_0_hsl(var(--border)/0.6),0_8px_24px_-12px_hsl(var(--midnight)/0.10)]"
          : "bg-background/60 backdrop-blur-md border-b border-transparent"
      }`}
    >
      <div className="container mx-auto flex items-center justify-between h-[72px] px-4 lg:px-8">
        <a href="#" className="flex items-center gap-2.5 group">
          <div className="relative">
            <div className="absolute inset-0 bg-royal/20 blur-md rounded-full group-hover:bg-royal/30 transition-colors" />
            <img src={mabeleLogo} alt="MABELE" className="relative h-9 w-9 object-contain" />
          </div>
          <div className="flex flex-col leading-none">
            <span className="font-heading font-extrabold text-xl text-foreground tracking-tight">MABELE</span>
            <span className="text-[9px] font-semibold text-muted-foreground tracking-[0.18em] uppercase mt-0.5">by Flow Tech DRC</span>
          </div>
        </a>

        <nav className="hidden lg:flex items-center gap-0.5 p-1 rounded-2xl bg-muted/40 border border-border/40">
          {navLinks.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="px-3.5 py-1.5 text-[13px] font-semibold text-foreground/70 hover:text-royal hover:bg-background rounded-xl transition-all"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="hidden lg:flex items-center gap-2.5">
          <a
            href="#inscription"
            className="px-4 py-2 text-sm font-semibold text-foreground/80 hover:text-royal transition-colors"
          >
            Se connecter
          </a>
          <a
            href="#inscription"
            className="px-5 py-2.5 text-sm font-bold gradient-golden text-accent-foreground rounded-xl shadow-golden hover:translate-y-[-1px] transition-all"
          >
            Créer un compte
          </a>
        </div>

        <button
          className="lg:hidden p-2 rounded-xl hover:bg-muted transition-colors"
          onClick={() => setOpen(!open)}
          aria-label="Menu"
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div className="lg:hidden bg-background border-t border-border px-4 pb-6 pt-2 space-y-1 animate-fade-in">
          {navLinks.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="block px-3 py-3 font-semibold text-foreground/80 hover:text-royal hover:bg-surface-blue rounded-xl transition-colors"
              onClick={() => setOpen(false)}
            >
              {l.label}
            </a>
          ))}
          <div className="flex gap-2 pt-3">
            <a href="#inscription" className="flex-1 text-center px-4 py-3 text-sm font-semibold border border-border text-foreground rounded-xl">
              Se connecter
            </a>
            <a href="#inscription" className="flex-1 text-center px-4 py-3 text-sm font-bold gradient-golden text-accent-foreground rounded-xl shadow-golden">
              Créer un compte
            </a>
          </div>
        </div>
      )}
    </header>
  );
};

export default MabeleHeader;
