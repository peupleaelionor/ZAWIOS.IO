ZAWIOS Logo Pack (single source of truth)
========================================

FILES
- public/brand/logo/zawios-mark.svg          (64×64 master, transparent)
- public/brand/logo/zawios-mark-mono.svg     (64×64, currentColor)
- public/brand/logo/zawios-tiny.svg          (32×32, small sizes)
- public/brand/logo/zawios-app-icon.svg      (512×512, light app icon background)

RECOMMENDED USAGE (Next.js)
- Navbar/Auth/Footer: use zawios-mark.svg (or mono if theming)
- Favicons: export PNGs at 16/32/48 + apple-touch 180 + PWA 192/512
- PWA manifest icons should reference PNGs (generated from SVG)

EXPORT PNGS
Run:
  npm i -D sharp
  node scripts/generate-icons.mjs

This will write:
  public/icons/favicon-16.png
  public/icons/favicon-32.png
  public/icons/favicon-48.png
  public/icons/apple-touch-180.png
  public/icons/pwa-192.png
  public/icons/pwa-512.png

Then update metadata/manifest to point to /icons/*.
